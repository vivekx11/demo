import React, { ReactNode } from 'react';

interface SkillBadgeProps {
  icon: ReactNode;
  name: string;
}

const SkillBadge: React.FC<SkillBadgeProps> = ({ icon, name }) => {
  return (
    <div className="flex flex-col items-center gap-4 p-6 rounded-xl bg-white dark:bg-white/5 shadow-lg dark:shadow-none hover:bg-gray-50 dark:hover:bg-white/10 transition-colors">
      <div className="text-primary-light dark:text-primary-dark w-12 h-12">
        {icon}
      </div>
      <span className="text-lg font-medium">{name}</span>
    </div>
  );
};

export default SkillBadge;