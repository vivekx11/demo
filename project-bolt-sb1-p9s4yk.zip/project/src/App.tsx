import React, { useState, useEffect } from 'react';
import { Code, Briefcase, User2, Mail, ExternalLink, Github, Linkedin, Terminal } from 'lucide-react';
import ProjectCard from './components/ProjectCard';
import SkillBadge from './components/SkillBadge';
import ThemeToggle from './components/ThemeToggle';

function App() {
  const [activeSection, setActiveSection] = useState('hero');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => setIsLoading(false), 1500);
  }, []);

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black dark:bg-white flex items-center justify-center">
        <Terminal className="w-16 h-16 text-white dark:text-black animate-pulse" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gradient-to-br dark:from-gray-900 dark:to-black text-gray-900 dark:text-white transition-colors duration-200">
      <nav className="fixed top-0 w-full bg-white/50 dark:bg-black/50 backdrop-blur-lg z-50 border-b border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <span className="text-2xl font-bold bg-gradient-to-r from-primary-light to-purple-600 dark:from-primary-dark dark:to-pink-600 bg-clip-text text-transparent">
            Portfolio
          </span>
          <div className="flex items-center gap-6">
            {['About', 'Projects', 'Skills', 'Contact'].map((item) => (
              <button
                key={item}
                className="hover:text-primary-light dark:hover:text-primary-dark transition-colors"
                onClick={() => setActiveSection(item.toLowerCase())}
              >
                {item}
              </button>
            ))}
            <ThemeToggle />
          </div>
        </div>
      </nav>

      <main className="pt-20">
        {/* Hero Section */}
        <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-purple-900/10 via-transparent to-transparent dark:from-purple-900/20" />
          <div className="container mx-auto px-6 flex flex-col items-center text-center relative z-10">
            <h1 className="text-6xl font-bold mb-6 animate-fade-in">
              Creative Developer
              <span className="block text-primary-light dark:text-primary-dark">Building Digital Experiences</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl">
              Transforming ideas into elegant, interactive web solutions with modern technologies
              and creative design approaches.
            </p>
            <div className="flex gap-4">
              <a href="#contact" className="bg-primary-light dark:bg-primary-dark hover:bg-purple-700 dark:hover:bg-purple-600 px-8 py-3 rounded-full transition-colors text-white">
                Get in Touch
              </a>
              <a href="#projects" className="border border-primary-light dark:border-primary-dark px-8 py-3 rounded-full hover:bg-primary-light/10 dark:hover:bg-primary-dark/20 transition-all">
                View Work
              </a>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section className="py-20 bg-gray-50 dark:bg-black/50">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl font-bold mb-12 text-center">Featured Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <ProjectCard
                title="E-Commerce Platform"
                description="A modern e-commerce solution with real-time inventory and AI-powered recommendations."
                image="https://images.unsplash.com/photo-1661956602116-aa6865609028?auto=format&fit=crop&q=80&w=800"
                tags={['React', 'Node.js', 'MongoDB']}
              />
              <ProjectCard
                title="Portfolio Website"
                description="A creative portfolio showcasing work with interactive animations and smooth transitions."
                image="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800"
                tags={['React', 'TypeScript', 'Tailwind']}
              />
              <ProjectCard
                title="Task Management"
                description="Collaborative task management app with real-time updates and analytics dashboard."
                image="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=800"
                tags={['React', 'Firebase', 'Charts']}
              />
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl font-bold mb-12 text-center">Skills & Technologies</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <SkillBadge icon={<Code />} name="Frontend Development" />
              <SkillBadge icon={<Terminal />} name="Backend Development" />
              <SkillBadge icon={<Briefcase />} name="UI/UX Design" />
              <SkillBadge icon={<User2 />} name="User Experience" />
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20 bg-gray-50 dark:bg-black/50">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl font-bold mb-12 text-center">Get in Touch</h2>
            <div className="max-w-2xl mx-auto">
              <div className="flex justify-center gap-6 mb-8">
                <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="hover:text-primary-light dark:hover:text-primary-dark transition-colors">
                  <Github className="w-8 h-8" />
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-primary-light dark:hover:text-primary-dark transition-colors">
                  <Linkedin className="w-8 h-8" />
                </a>
                <a href="mailto:contact@example.com" className="hover:text-primary-light dark:hover:text-primary-dark transition-colors">
                  <Mail className="w-8 h-8" />
                </a>
              </div>
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full px-4 py-3 rounded-lg bg-white dark:bg-white/10 border border-gray-200 dark:border-primary-dark/50 focus:border-primary-light dark:focus:border-primary-dark focus:outline-none transition-colors"
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full px-4 py-3 rounded-lg bg-white dark:bg-white/10 border border-gray-200 dark:border-primary-dark/50 focus:border-primary-light dark:focus:border-primary-dark focus:outline-none transition-colors"
                />
                <textarea
                  placeholder="Your Message"
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg bg-white dark:bg-white/10 border border-gray-200 dark:border-primary-dark/50 focus:border-primary-light dark:focus:border-primary-dark focus:outline-none transition-colors"
                />
                <button className="w-full bg-primary-light dark:bg-primary-dark hover:bg-purple-700 dark:hover:bg-purple-600 px-8 py-3 rounded-lg transition-colors text-white">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;